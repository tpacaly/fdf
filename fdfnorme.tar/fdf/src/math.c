/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   math.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/09 09:29:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/09 09:29:03 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

t_gene		calcule_point(t_gene a, int x, int y)
{
	int *tableauvaleurs;
	int c;
	int z;

	tableauvaleurs = a.yy;
	c = (a.tailllig * y) + x;
	z = tableauvaleurs[c];
	a.xyz = ((x - y) * (a.pixxecart) / MULTI_X);
	a.zyx = ((x + y) * (a.pixyecart) / MULTI_Y) + (z * MULTI_Z);
	a.xyz += a.pixxdebut;
	a.zyx += a.pixydebut;
	return (a);
}

void		phase_1(t_gene a)
{
	int b;
	int c;

	b = 0;
	c = 0;
	while (c < a.compte)
	{
		while (b < a.tailllig)
		{
			if (b != 0)
			{
				a = calcule_point(a, (b - 1), c);
				a.xmin = a.xyz;
				a.ymin = a.zyx;
				a = calcule_point(a, b, c);
				a.xmax = a.xyz;
				a.ymax = a.zyx;
				trace_ligne(a, 0xffffff);
			}
			b++;
		}
		b = 0;
		c++;
	}
}

void		phase_2(t_gene a)
{
	int b;
	int c;

	b = 0;
	c = 0;
	while (b < a.tailllig)
	{
		while (c < a.compte)
		{
			if (c != 0)
			{
				a = calcule_point(a, b, (c - 1));
				a.xmax = a.xyz;
				a.ymax = a.zyx;
				a = calcule_point(a, b, c);
				a.xmin = a.xyz;
				a.ymin = a.zyx;
				trace_ligne(a, 0xffffff);
			}
			c++;
		}
		c = 0;
		b++;
	}
}

void		afficher_points(t_gene a)
{
	int f;
	int g;
	int *h;

	h = a.yy;
	f = 0;
	g = 0;
	a.zyx = 0;
	a.xyz = 0;
	phase_1(a);
	a.zyx = 0;
	a.xyz = 0;
	phase_2(a);
}
