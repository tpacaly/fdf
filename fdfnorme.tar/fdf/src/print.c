/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/09 09:52:45 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/09 09:52:48 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int				trace_point(t_gene a, int x, int y, int couleur)
{
	if (x > a.pixxfin || x < 0 || y == 0 || y > a.pixyfin)
		return (-1);
	return (mlx_pixel_put(a.mlx, a.map, x, y, couleur));
}

void			trace_ligne(t_gene a, int color)
{
	int		x;
	int		y;
	double	b;
	double	c;

	x = a.xmin;
	y = 0;
	b = (double)(a.ymax - a.ymin) / (a.xmax - a.xmin);
	c = a.ymin - (b * a.xmin);
	while (x <= a.xmax)
	{
		y = (int)(b * x + c);
		trace_point(a, x, y, color);
		x++;
	}
}

t_gene			calcule_taille_ecran(t_gene a)
{
	int ecarty;
	int debutx;
	int ecartx;
	int debuty;

	debutx = 0;
	debuty = 0;
	ecarty = 0;
	ecartx = 0;
	ecartx = ((MAX_X - 0x100) / a.tailllig);
	debutx = ((MAX_X - 0x100) % a.tailllig) + 0x80;
	ecarty = ((MAX_Y - 0x80) / a.compte);
	debuty = (((MAX_Y - 0x80) % a.compte) / 2) + 0x40;
	a.pixxecart = ecartx;
	a.pixxdebut = debutx + (MAX_X / 3);
	a.pixyecart = ecarty / 2;
	a.pixydebut = debuty + (MAX_Y / 6);
	ecartx *= a.tailllig;
	ecartx += debutx;
	ecarty *= a.compte;
	ecarty += debuty;
	a.pixxfin = ecartx;
	a.pixyfin = ecarty;
	return (a);
}
