/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   math.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/09 09:29:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/09 09:29:03 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

t_gene		calcule_point(t_gene a, int x, int y)
{
	int c;
	int z;
	int *h;

	h = a.yy;
	c = x + (a.tailllig * y);
	z = h[c];
	a.xyz = ((x - y) * a.pixxecart) / MULTI_X;
	a.zyx = (x + y) * a.pixyecart / MULTI_Y + z * MULTI_Z;
	a.xyz += a.pixxdebut;
	a.zyx += a.pixydebut;
	return (a);
}

void		vertical_lines(t_gene a)
{
	int x;
	int y;

	x = 0;
	y = 0;
	while (y < a.compte)
	{
		while (x < a.tailllig)
		{
			if (x != 0)
			{
				a = calcule_point(a, (x - 1), y);
				a.xmin = a.xyz;
				a.ymin = a.zyx;
				a = calcule_point(a, x, y);
				a.xmax = a.xyz;
				a.ymax = a.zyx;
				trace_ligne(a, 0xffffff);
			}
			x++;
		}
		x = 0;
		y++;
	}
}

void		horizontal_lines(t_gene a)
{
	int x;
	int y;

	x = 0;
	y = 0;
	while (x < a.tailllig)
	{
		while (y < a.compte)
		{
			if (y != 0)
			{
				a = calcule_point(a, x, (y - 1));
				a.xmax = a.xyz;
				a.ymax = a.zyx;
				a = calcule_point(a, x, y);
				a.xmin = a.xyz;
				a.ymin = a.zyx;
				trace_ligne(a, 0xffffff);
			}
			y++;
		}
		y = 0;
		x++;
	}
}

int			afficher_points(t_gene a, int fd, int compteur, char **tableau)
{
	close(fd);
	a.compte = compteur;
	ft_affiche("%d %d\n", a.tailllig, a.compte);
	a = parsing(a, tableau);
	if (a.yy == 0)
		return (ft_affiche("FICHIER NON VALIDE\n"));
	a = calcule_taille_ecran(a);
	ft_affiche("appuyez sur une touche pour lire le fichier : %s \n",
		a.nomfichier);
	getchar();
	vertical_lines(a);
	horizontal_lines(a);
	while (compteur-- <= 0)
		ft_strdel(&tableau[compteur]);
	return (a.tailllig);
}
