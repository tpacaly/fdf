/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/09 08:59:34 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/09 08:59:38 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int		tailletableau(char *a)
{
	int c;
	int b;

	c = 0;
	b = 0;
	while (a[b])
	{
		if ((a[b] < 0x3a && a[b] > 0x2f) || a[b] == 0x2d || a[b] == 0x2d)
		{
			c++;
			while ((a[b] < 0x3a && a[b] > 0x2f) || a[b] == 0x2d || a[b] == 0x2d)
				b++;
		}
		else if (a[b] == ' ')
			b++;
		else
			return (0);
	}
	return (c);
}

void	free_tab(char **t)
{
	int i;

	i = 0;
	while (t[i])
	{
		ft_strdel(&t[i]);
		i++;
	}
	ft_strdel(&t[i]);
}

t_gene	fonction(t_gene a, int e, char **vinyl, int *h)
{
	char	**buff;
	int		kevin;
	int		z;
	int		f;

	kevin = 0;
	z = 0;
	f = 0;
	while (f < a.compte)
	{
		buff = ft_strsplit(vinyl[f], ' ');
		e = 0;
		while (buff[e])
		{
			z = ft_atoi(buff[e]);
			kevin = ((f * a.tailllig) + e);
			h[kevin] = z;
			e++;
		}
		ft_strdel(&vinyl[f++]);
		free_tab(buff);
		free(buff);
		buff = 0;
	}
	return (a);
}

t_gene	parsing(t_gene a, char **vinyl)
{
	int		*h;
	int		x;
	int		e;

	e = a.compte * a.tailllig;
	x = 0;
	if ((h = malloc(sizeof(int*) * e)) == NULL)
		return (a);
	a.yy = h;
	a = fonction(a, e, vinyl, h);
	return (a);
}
