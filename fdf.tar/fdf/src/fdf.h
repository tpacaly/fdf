/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/06/08 19:28:21 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/24 11:43:02 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FDF_H
# define FDF_H
# define MAX_X 2048
# define MAX_Y 1440
# define MAX_LIGNES 1000
# define MULTI_Z -5
# define MULTI_Y 3
# define MULTI_X 3
# include "../libft/libft.h"
# include "../minilibx_macos/mlx.h"

typedef struct			s_image
{
	int					x;
	int					y;
	char				*buff;
}						t_image;

typedef struct			s_gene
{
	void				*mlx;
	void				*map;
	t_image				*img;
	char				*nomfichier;
	int					compte;
	int					tailllig;
	int					pixxecart;
	int					pixxdebut;
	int					pixyecart;
	int					pixydebut;
	int					pixxfin;
	int					pixyfin;
	int					xmin;
	int					xmax;
	int					ymin;
	int					ymax;
	int					xyz;
	int					zyx;
	int					*yy;
	int					lastkey;
}						t_gene;

t_gene					parsing(t_gene a, char **vinyl);
t_gene					calcule_taille_ecran(t_gene a);
t_gene					liremap(char *fichier, t_gene a);
int						tailletableau(char *a);
int						afficher_points(t_gene a, int fd, int compteur,
		char **tableau);
void					trace_ligne(t_gene a, int color);
#endif
