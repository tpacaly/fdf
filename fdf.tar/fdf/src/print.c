/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/09 09:52:45 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/24 15:10:33 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int				trace_point(t_gene a, int x, int y, int couleur)
{
	if (x > a.pixxfin || x < 0 || y == 0 || y > a.pixyfin)
		return (-1);
	return (mlx_pixel_put(a.mlx, a.map, x, y, couleur));
}

t_gene			verify(t_gene a)
{
	int c;

	c = 0;
	if(a.xmin > a.xmax)
	{
		c = a.xmax;
		a.xmax = a.xmin;
		a.xmin = c;
	}
	if(a.ymin > a.ymax)
	{
		c = a.ymax;
		a.ymax = a.ymin;
		a.ymin = c;
	}
	return(a);
}

int				ft_abs(int a)
{
	a = (a < 0) ? (a * -1) : a;
	return(a);
}

void trace_ligne(t_gene a, int color) {
	int dx,dy,i,xinc,yinc,cumul,x,y ;
	x = a.xmin ;
	y = a.ymin ;
	dx = a.xmax - a.xmin ;
	dy = a.ymax - a.ymin ;
	xinc = ( dx > 0 ) ? 1 : -1 ;
	yinc = ( dy > 0 ) ? 1 : -1 ;
	dx = ft_abs(dx) ;
	dy = ft_abs(dy) ;
	trace_point(a,x,y, color) ;
	if ( dx > dy ) {
		cumul = dx / 2 ;
		for ( i = 1 ; i <= dx ; i++ ) {
			x += xinc ;
			cumul += dy ;
			if ( cumul >= dx ) {
				cumul -= dx ;
				y += yinc ; }
			trace_point(a, x,y, color) ; } }
	else {
		cumul = dy / 2 ;
		for ( i = 1 ; i <= dy ; i++ ) {
			y += yinc ;
			cumul += dx ;
			if ( cumul >= dy ) {
				cumul -= dy ;
				x += xinc ; }
			trace_point(a, x,y, color) ; } }
}

t_gene			calcule_taille_ecran(t_gene a)
{
	int ecarty;
	int debutx;
	int ecartx;
	int debuty;

	debutx = 0;
	debuty = 0;
	ecarty = 0;
	ecartx = 0;
	ecartx = ((MAX_X - 0x100) / a.tailllig);
	debutx = ((MAX_X - 0x100) % a.tailllig) + 0x80;
	ecarty = ((MAX_Y - 0x80) / a.compte);
	debuty = (((MAX_Y - 0x80) % a.compte) / 2) + 0x40;
	a.pixxecart = ecartx;
	a.pixxdebut = debutx + (MAX_X / 3);
	a.pixyecart = ecarty / 2;
	a.pixydebut = debuty + (MAX_Y / 6);
	ecartx *= a.tailllig;
	ecartx += debutx;
	ecarty *= a.compte;
	ecarty += debuty;
	a.pixxfin = ecartx;
	a.pixyfin = ecarty;
	return (a);
}
