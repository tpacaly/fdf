/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/06/08 19:18:43 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/24 11:45:08 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int				hook_keydown(int key, t_gene *a)
{
	if (key == 53)
		exit(0);
	a->lastkey = key;
	return (0);
}

t_gene			ft_erreur(char **tab, int d, int fd, t_gene a)
{
	while (--d > -1)
		ft_strdel(tab++);
	ft_affiche("ERREUR DE LECTURE DU FICHIER\n");
	close(fd);
	a.tailllig = 0;
	return (a);
}

t_gene			liremap(char *fichier, t_gene a)
{
	int			fd;
	char		*ligne;
	char		*tableau[MAX_LIGNES];
	int			retour;
	int			compteur;

	compteur = 0;
	if ((fd = open(fichier, 2)) == -1)
		return (ft_erreur(tableau, compteur, fd, a));
	if ((retour = get_next_line(fd, &ligne)) == -1 || (retour == 0))
		return (ft_erreur(tableau, compteur, fd, a));
	if ((a.tailllig = tailletableau(ligne)) == 0)
		return (ft_erreur(tableau, compteur, fd, a));
	while (retour != 0)
	{
		tableau[compteur] = ligne;
		compteur++;
		if ((retour = get_next_line(fd, &ligne)) == -1)
			return (ft_erreur(tableau, compteur, fd, a));
	}
	if (a.tailllig == 0 || compteur == 0)
		return (ft_erreur(tableau, compteur, fd, a));
	afficher_points(a, fd, compteur, tableau);
	return (a);
}

static int		ft_red_cross(void)
{
	exit(0);
	return (0);
}

int				main(int c, char **v)
{
	t_gene *b;
	t_gene a;

	if (!(b = (t_gene*)malloc(sizeof(t_gene))))
		exit(0);
	a = *b;
	if (c != 2)
		return (0);
	if ((a.mlx = mlx_init()) == 0)
		return (ft_affiche("mlx_init = 0\n"));
	a.map = mlx_new_window(a.mlx, MAX_X, MAX_Y, "FDF");
	a.nomfichier = v[1];
	a = liremap(v[1], a);
	if (a.tailllig == 0)
		exit(0);
	mlx_hook(a.map, 17, 0, ft_red_cross, 0);
	mlx_key_hook(a.map, hook_keydown, b);
	mlx_loop(a.mlx);
	return (0);
}
